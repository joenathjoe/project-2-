<?php
$name= $_post['name'];
$visitor_email= $_post['email'];
$subject = $_post['subject'];
$message = $_post['message'];


$email_form='joanathjoe98@gmail.com';

$email_subject= 'New form submission';

$email_body="user Name: $name.\n".
            "user Email:$visitor_email.\n".
			"Subject:$Subject.\n".
			"User Message:$message.\n";


$to = 'joanathjoe98@gmail.com';

$headers = "form: $email_from \r\n";

$headers = "Reply-To: $visitor_email \r\n";

mail($to,$email_subject,$email_body,$headers);
header("Location: contact.html");



?>